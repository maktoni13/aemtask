package com.aemtask.core.filters;

import com.adobe.acs.commons.util.BufferingResponse;
import org.apache.sling.engine.EngineConstants;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

//@Component(service = Filter.class,
//        property = {
//                Constants.SERVICE_DESCRIPTION + "=Demo to filter incoming requests",
//                EngineConstants.SLING_FILTER_SCOPE + "=" + EngineConstants.FILTER_SCOPE_REQUEST,
//                Constants.SERVICE_RANKING + ":Integer=-700"
//
//        })
@Component(service = Filter.class, property = {
        Constants.SERVICE_DESCRIPTION + "= Filter incoming requests and replace company name in response",
        EngineConstants.SLING_FILTER_SCOPE + "=" + EngineConstants.FILTER_SCOPE_REQUEST,
        EngineConstants.SLING_FILTER_PATTERN + "=/content/we-retail/.*",
        Constants.SERVICE_RANKING + "=-700"
})
public class CompanyReplaceFilter implements Filter {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        final HttpServletRequest request = (HttpServletRequest) servletRequest;
        final HttpServletResponse response = (HttpServletResponse) servletResponse;

        PrintWriter out = response.getWriter();
        //Generate a response wrapper with a different output stream
        BufferingResponse responseWrapper = new BufferingResponse(response);
        //Process all in the chain (=get the jsp response..)
        filterChain.doFilter(request, responseWrapper);
        //Parse the response
        out.write(responseWrapper.getContents()); //Just + for clear display, better use a StringUtils.concat



//        BufferingResponse bufferingResponse = new BufferingResponse(response);
////        filterChain.doFilter(request, bufferingResponse);
//        filterChain.doFilter(request, response);

//        // Get contents
//        String contents = bufferingResponse.getContents();
//        logger.info("hahaha " + (contents == null));
//        logger.info("hahaha " + contents);
//
//        if (contents != null && bufferingResponse.getContentType().contains("html")) {
////            contents = contents.replaceAll("Retail", "HAHAHA");
////            bufferingResponse.getWriter().write(contents);
//            logger.info("hahaha - finish");
//
//            //            final int bodyIndex = contents.indexOf("</body>");
////            if (bodyIndex != -1) {
////                final PrintWriter printWriter = bufferingResponse.getWriter();
////                printWriter.write(contents.substring(0, bodyIndex));
////                printWriter.write(appHTML);
////                printWriter.write(contents.substring(bodyIndex));
////                return;
////            }
//        }
////        if (contents != null) {
////            response.getWriter().write(contents);
////        }

    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void destroy() {

    }
}
